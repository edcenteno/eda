<?php


$conexion = new mysqli("localhost", "root", "", "bderror");

//$conexion = new mysqli("localhost", "atorresg_070575", "10002053", "atorresg_dbsol");

	if (mysqli_connect_errno()) {
	    printf("Connect failed: %s\n", mysqli_connect_error());
	    exit();
	}
